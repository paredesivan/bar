-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 20-07-2016 a las 04:02:42
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `flashbd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cadetes`
--

CREATE TABLE IF NOT EXISTS `cadetes` (
  `idCadete` int(8) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `telefono` int(20) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `usuarios_username` varchar(45) NOT NULL,
  PRIMARY KEY (`idCadete`,`usuarios_username`),
  KEY `fk_cadetes_usuarios1_idx` (`usuarios_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cadetes`
--

INSERT INTO `cadetes` (`idCadete`, `nombre`, `apellido`, `direccion`, `telefono`, `email`, `usuarios_username`) VALUES
(23131, 'jose lopez', 'paredes', 'uruguay 1682', 341340, 'cuatroacero2@hotmail.com', 'paredes'),
(14729579, 'mario', 'zabalza', 'uruguay 1682', 341340, 'cuatroacero2@hotmail.com', 'paredes'),
(16985702, 'raul', 'zabalza', 'uruguay 1682', 341340, 'cuatroacero2@hotmail.com', 'paredes'),
(31631228, 'ivan paredes', 'paredes', 'uruguay 1682', 341340, 'cuatroacero2@hotmail.com', 'paredes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `nombreCategoria` varchar(45) NOT NULL,
  `imagen` varchar(100) DEFAULT NULL,
  `usuarios_username` varchar(45) NOT NULL,
  PRIMARY KEY (`nombreCategoria`,`usuarios_username`),
  KEY `fk_categorias_usuarios1_idx` (`usuarios_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`nombreCategoria`, `imagen`, `usuarios_username`) VALUES
('bebida', NULL, 'paredes'),
('empanadas', NULL, 'paredes'),
('pizzas', NULL, 'paredes'),
('varios', NULL, 'paredes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `idclientes` int(11) NOT NULL AUTO_INCREMENT,
  `nombreYapellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) NOT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `usuarios_username` varchar(45) NOT NULL,
  PRIMARY KEY (`idclientes`,`usuarios_username`),
  KEY `fk_clientes_usuarios1_idx` (`usuarios_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE IF NOT EXISTS `pedidos` (
  `nroPedido` int(11) NOT NULL AUTO_INCREMENT,
  `idCliente` int(11) NOT NULL,
  `idCadete` int(8) NOT NULL,
  `fecha` date DEFAULT NULL,
  `usuarios_username` varchar(45) NOT NULL,
  PRIMARY KEY (`nroPedido`,`idCliente`,`idCadete`,`usuarios_username`),
  KEY `fk_pedidos_clientes1_idx` (`idCliente`),
  KEY `fk_pedidos_cadetes1_idx` (`idCadete`),
  KEY `fk_pedidos_usuarios1_idx` (`usuarios_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_has_productos`
--

CREATE TABLE IF NOT EXISTS `pedidos_has_productos` (
  `nroPedido` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `usuarios_username` varchar(45) NOT NULL,
  PRIMARY KEY (`nroPedido`,`idProducto`,`usuarios_username`),
  KEY `fk_pedidos_has_productos_productos1_idx` (`idProducto`),
  KEY `fk_pedidos_has_productos_pedidos1_idx` (`nroPedido`),
  KEY `fk_pedidos_has_productos_usuarios1_idx` (`usuarios_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `idproductos` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCategoria` varchar(45) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `imagen` varchar(100) DEFAULT NULL,
  `costo` float DEFAULT NULL,
  `precio` float NOT NULL,
  `usuarios_username` varchar(45) NOT NULL,
  PRIMARY KEY (`idproductos`,`nombreCategoria`,`usuarios_username`),
  KEY `fk_productos_categorias1_idx` (`nombreCategoria`),
  KEY `fk_productos_usuarios1_idx` (`usuarios_username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`idproductos`, `nombreCategoria`, `nombre`, `stock`, `imagen`, `costo`, `precio`, `usuarios_username`) VALUES
(2, 'pizzas', 'rucula', 10, NULL, 10, 70, 'paredes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `username` varchar(45) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `empresa` varchar(45) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`username`, `nombre`, `apellido`, `direccion`, `telefono`, `email`, `empresa`, `password`) VALUES
('paredes', 'ivan', 'paredes', 'uruguay 1682', NULL, NULL, 'paredessa', '123');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cadetes`
--
ALTER TABLE `cadetes`
  ADD CONSTRAINT `fk_cadetes_usuarios1` FOREIGN KEY (`usuarios_username`) REFERENCES `usuarios` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `fk_categorias_usuarios1` FOREIGN KEY (`usuarios_username`) REFERENCES `usuarios` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `fk_clientes_usuarios1` FOREIGN KEY (`usuarios_username`) REFERENCES `usuarios` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedidos_cadetes1` FOREIGN KEY (`idCadete`) REFERENCES `cadetes` (`idCadete`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pedidos_clientes1` FOREIGN KEY (`idCliente`) REFERENCES `clientes` (`idclientes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pedidos_usuarios1` FOREIGN KEY (`usuarios_username`) REFERENCES `usuarios` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pedidos_has_productos`
--
ALTER TABLE `pedidos_has_productos`
  ADD CONSTRAINT `fk_pedidos_has_productos_pedidos1` FOREIGN KEY (`nroPedido`) REFERENCES `pedidos` (`nroPedido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pedidos_has_productos_productos1` FOREIGN KEY (`idProducto`) REFERENCES `productos` (`idproductos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pedidos_has_productos_usuarios1` FOREIGN KEY (`usuarios_username`) REFERENCES `usuarios` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_productos_usuarios1` FOREIGN KEY (`usuarios_username`) REFERENCES `usuarios` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`nombreCategoria`) REFERENCES `categorias` (`nombreCategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
