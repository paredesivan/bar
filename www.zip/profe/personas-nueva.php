<?php
include("includes/conexion.php");

$sql = "INSERT INTO personas (nombre, apellido, email, telefono, idCiudad) VALUES ('". $_POST["nombre"]. "',
'" . $_POST["apellido"]."','". $_POST["email"]. "',
'" . $_POST["telefono"]."', '".$_POST["idCiudad"]."')";

$rs = mysqli_query($db, $sql);

echo $sql;

header('Location: personas-lista.php');

// $id = mysqli_insert_id($rs);

?>