<?php 

include("includes/conexion.php");

$sql = "DELETE FROM personas WHERE id = " . $_GET["id"];
$rs = mysqli_query($db, $sql);

header('Location: personas-lista.php');

?>