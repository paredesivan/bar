<?php

include("menuLateral.php");

?>

<body>
<div class="login">
    <h1>Crear Cliente</h1>
    <form method="POST" action="insertarCliente.php">
        <input type="text" name="nombre" placeholder="nombre" required="required"/>
        <input type="text" name="apellido" placeholder="apellido" required="required"/>
        <input type="text" name="direccion" placeholder="direccion" required="required"/>
        <input type="text" name="telefono" placeholder="telefono" required="required"/>
        <input type="text" name="mail" placeholder="mail" required="required"/>

        <button type="submit" class="btn btn-primary btn-block btn-large">Crear</button>
    </form>
</div>
</body>
