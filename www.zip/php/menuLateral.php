<?php
include("cabecera.php");
?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link href='https://fonts.googleapis.com/css?family=Indie+Flower' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/css/menuLateral.css">

<nav class="nav2">
<!--    <div class="menuicon">-->
<!--        <i class="fa fa-bars"></i>-->
<!--    </div>-->

    <ul>
        <li class="li2 bordeInferior"><a href="crearFactura.php">Crear Factura</a></li>
        <li class="li2 bordeInferior"><a href="crearCliente.php">Crear Cliente</a></li>
        <li class="li2 bordeInferior"><a href="crearProducto.php">Crear Producto</a></li>
        <li class="li2 bordeInferior"><a href="crearCadete.php">Crear Cadete</a></li>
        <li class="li2 bordeInferior"><a href="crearCategoria.php">Crear Categoria</a></li>
    </ul>
</nav>
<script src="/php/less.js" type="text/javascript"></script>