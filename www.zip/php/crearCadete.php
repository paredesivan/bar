<?php

include("menuLateral.php");

?>

<body>
<div class="login">
    <h1>Crear Cadete</h1>
    <form method="POST" action="insertarCadete.php">
        <input type="text" name="nombre" placeholder="nombre" required="required"/>
        <input type="number" name="dni" placeholder="dni" required="required"/>
        <input type="text" name="apellido" placeholder="apellido" required="required"/>
        <input type="text" name="direccion" placeholder="direccion" required="required"/>
        <input type="number" name="telefono" placeholder="telefono" required="required"/>
        <input type="text" name="email" placeholder="mail" required="required"/>

        <button type="submit" class="btn btn-primary btn-block btn-large">Crear</button>
    </form>
</div>
</body>
