<?php
include("conexion.php");
include("busquedaCategorias.php");


echo "<select name='productoElegido'>";
while ($fila = mysqli_fetch_array($rs)) {
    echo "<option value='" . $fila['nombreCategoria'] . "'>" . $fila['nombreCategoria'] . "</option>";
}
echo "</select>";