<?php
include("busquedaCategorias.php");

?>

    <ul id="navbar1" class="navbar">
        <!--    <li id="home" class="btn img border-right">-->
        <!--        <a href="#">-->
        <!--			<span class="img">-->
        <!--				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">-->
        <!--                    <path-->
        <!--                        style="text-indent:0;text-align:start;line-height:normal;text-transform:none;block-progression:tb;-inkscape-font-specification:Bitstream Vera Sans"-->
        <!--                        d="M 16 2.59375 L 15.28125 3.28125 L 2.28125 16.28125 L 3.71875 17.71875 L 5 16.4375 L 5 27 L 5 28 L 6 28 L 13 28 L 14 28 L 14 27 L 14 18 L 18 18 L 18 27 L 18 28 L 19 28 L 26 28 L 27 28 L 27 27 L 27 16.4375 L 28.28125 17.71875 L 29.71875 16.28125 L 16.71875 3.28125 L 16 2.59375 z M 16 5.4375 L 25 14.4375 L 25 26 L 20 26 L 20 17 L 20 16 L 19 16 L 13 16 L 12 16 L 12 17 L 12 26 L 7 26 L 7 14.4375 L 16 5.4375 z"-->
        <!--                        color="#000" overflow="visible" font-family="Bitstream Vera Sans"/>-->
        <!--                </svg>-->
        <!--			</span>-->
        <!---->
        <!--            <div class="arrow"></div>-->
        <!--        </a>-->
        <!--    </li>-->


        <!--    echo "<select name='productoElegido'>";-->
        <!--        while ($fila = mysqli_fetch_array($rs)) {-->
        <!--        echo "-->
        <!--        <option value='" . $fila[' nombreCategoria-->
        <!--        '] . "'>" . $fila['nombreCategoria'] . "</option>";-->
        <!--        }-->
        <!--        echo "</select>";-->


        <!--    echo "-->
        <!--    <li id="btn1" class="btn2  border-right">-->
        <!--        <a href="#">-->
        <!--            <span class="title">PIZZAS</span>-->
        <!---->
        <!--            <div class="arrow"></div>-->
        <!--        </a>-->
        <!--    </li>-->

//    <!---->
//    <!--    <li id="btn1" class="btn2  border-right">-->
//    <!--        <a href="#">-->
//    <!--            <span class="title">PIZZAS</span>-->
//    <!---->
//    <!--            <div class="arrow"></div>-->
//    <!--        </a>-->
//    <!--    </li>-->
//    <!--    <li id="btn2" class="btn2 text border-right">-->
//    <!--        <a href="#">-->
//    <!--            <span class="title">CARLITOS</span>-->
//    <!---->
//    <!--            <div class="arrow"></div>-->
//    <!--        </a>-->
//    <!--    </li>-->
//    <!--    <li id="btn3" class="btn2 text border-right">-->
//    <!--        <a href="#">-->
//    <!--            <span class="title">BEBIDAS</span>-->
//    <!---->
//    <!--            <div class="arrow"></div>-->
//    <!--        </a>-->
//    <!--    </li>-->
//    <!--    <li id="btn4" class="btn2 text border-right">-->
//    <!--        <a href="#">-->
//    <!--            <span class="title">VARIOS</span>-->
//    <!---->
//    <!--            <div class="arrow"></div>-->
//    <!--        </a>-->
//    <!--    </li>-->
//    <!--    <li id="btn5" class="btn2 text">-->
//    <!--        <a href="#">-->
//    <!--            <span class="title">MINUTAS</span>-->
//    <!---->
//    <!--            <div class="arrow"></div>-->
//    <!--        </a>-->
//    <!--    </li>-->
//    <!--</ul>-->