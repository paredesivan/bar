<?php
include("busquedaCategorias.php");
include("conexion.php");
?>

<ul id="navbar1" class="navbar">


    <!--    <li id="btn1" class="btn2  border-right">-->
    <!--        <a href="#">-->
    <!--            <span class="title">PIZZAS</span>-->
    <!---->
    <!--            <div class="arrow"></div>-->
    <!--        </a>-->
    <!--    </li>-->

    <?php
    while ($fila = mysqli_fetch_array($rs)) {

        echo "<li id='btn" . $fila['color'] . "' class='btn2 border-right'>";

        echo "<a href='#'>";
        echo "<span class='title'>" . $fila['nombreCategoria'] . "</span >";

        echo "<div class='arrow' ></div >";
        echo "</a>";
        echo "</li >";
    }
    echo "</ul >"
    ?>
