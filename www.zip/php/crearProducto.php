<?php

include("menuLateral.php");

?>

<body>
<div class="login">
    <h1>Crear Producto</h1>
    <form method="POST" action="insertarProducto.php">
        <input type="text" name="nombre" placeholder="nombre" required="required"/>
        <input type="text" name="stock" placeholder="stock" required="required"/>
        <input type="text" name="costo" placeholder="costo" required="required"/>
        <input type="text" name="precio" placeholder="precio" required="required"/>

        <?php

        include("listarCategorias.php");

        ?>
        <button type="submit" class="btn btn-primary btn-block btn-large">Crear</button>
    </form>
</div>
</body>
