<?php

include("php/cabecera.php");

?>

<body>
<div class="login">
    <h1>Iniciar Sesion</h1>
    <form method="POST" action="php/login.php">
        <input type="text" name="usuario" placeholder="Usuario" required="required"/>
        <input type="password" name="password" placeholder="Password" required="required"/>
        <button type="submit" class="btn btn-primary btn-block btn-large">Entrar</button>
    </form>
	<!--Panel-->
<div class="card">
    <div class="card-header danger-color-dark white-text">
        Argenta
    </div>
    <div class="card-block">
        <h4 class="card-title">Casa</h4>
        <p class="card-text">vamos todos a la cancha.</p>
        <a class="btn btn-danger">ingresar</a>
    </div>
</div>
<!--/.Panel-->
</div>
</body>

